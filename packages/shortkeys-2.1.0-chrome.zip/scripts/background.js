/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(2);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global localStorage, chrome */

var copyToClipboard = function copyToClipboard(text) {
  var copyDiv = document.createElement('div');
  copyDiv.contentEditable = true;
  document.body.appendChild(copyDiv);
  copyDiv.innerHTML = text;
  copyDiv.unselectable = 'off';
  copyDiv.focus();
  document.execCommand('SelectAll');
  document.execCommand('Copy', false, null);
  document.body.removeChild(copyDiv);
};

var selectTab = function selectTab(direction) {
  chrome.tabs.query({ currentWindow: true }, function (tabs) {
    if (tabs.length <= 1) {
      return;
    }
    chrome.tabs.query({ currentWindow: true, active: true }, function (currentTabInArray) {
      var currentTab = currentTabInArray[0];
      var toSelect = void 0;
      switch (direction) {
        case 'next':
          toSelect = tabs[(currentTab.index + 1 + tabs.length) % tabs.length];
          break;
        case 'previous':
          toSelect = tabs[(currentTab.index - 1 + tabs.length) % tabs.length];
          break;
        case 'first':
          toSelect = tabs[0];
          break;
        case 'last':
          toSelect = tabs[tabs.length - 1];
          break;
      }
      chrome.tabs.update(toSelect.id, { highlighted: true });
      chrome.tabs.update(currentTab.id, { highlighted: false });
    });
  });
};

/**
 * Helper function to convert glob/wildcard * syntax to valid RegExp for URL checking.
 *
 * @param glob
 * @returns {RegExp}
 */
var globToRegex = function globToRegex(glob) {
  // Use a regexp if the url starts and ends with a slash `/`
  if (/^\/.*\/$/.test(glob)) return new RegExp(glob.replace(/^\/(.*)\/$/, '$1'));

  var specialChars = '\\^$*+?.()|{}[]';
  var regexChars = ['^'];
  for (var i = 0; i < glob.length; ++i) {
    var c = glob.charAt(i);
    if (c === '*') {
      regexChars.push('.*');
    } else {
      if (specialChars.indexOf(c) >= 0) {
        regexChars.push('\\');
      }
      regexChars.push(c);
    }
  }
  regexChars.push('$');
  return new RegExp(regexChars.join(''));
};

/**
 * Helper function to determine if the current site is blacklisted or not.
 *
 * @param keySetting
 * @param url
 * @returns {boolean}
 */
var isAllowedSite = function isAllowedSite(keySetting, url) {
  if (keySetting.blacklist !== 'true' && keySetting.blacklist !== 'whitelist') {
    // This shortcut is allowed on all sites (not blacklisted or whitelisted).
    return true;
  }
  var allowed = keySetting.blacklist === 'true';
  keySetting.sitesArray.forEach(function (site) {
    if (url.match(globToRegex(site))) {
      allowed = !allowed;
    }
  });
  return allowed;
};

var handleAction = function handleAction(action) {
  var request = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  if (action === 'cleardownloads') {
    chrome.browsingData.remove({ 'since': 0 }, { 'downloads': true });
  } else if (action === 'viewsource') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.create({ url: 'view-source:' + tab[0].url });
    });
  } else if (action === 'nexttab') {
    selectTab('next');
  } else if (action === 'prevtab') {
    selectTab('previous');
  } else if (action === 'firsttab') {
    selectTab('first');
  } else if (action === 'lasttab') {
    selectTab('last');
  } else if (action === 'newtab') {
    chrome.tabs.create({});
  } else if (action === 'reopentab') {
    chrome.sessions.getRecentlyClosed({ maxResults: 1 }, function (sessions) {
      var closedTab = sessions[0];
      chrome.sessions.restore(closedTab.sessionsId);
    });
  } else if (action === 'closetab') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.remove(tab[0].id);
    });
  } else if (action === 'clonetab') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.duplicate(tab[0].id);
    });
  } else if (action === 'onlytab') {
    chrome.tabs.query({ currentWindow: true, pinned: false, active: false }, function (tabs) {
      var ids = [];
      tabs.forEach(function (tab) {
        ids.push(tab.id);
      });
      chrome.tabs.remove(ids);
    });
  } else if (action === 'closelefttabs' || action === 'closerighttabs') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
      var currentTabIndex = tabs[0].index;
      chrome.tabs.query({ currentWindow: true, pinned: false, active: false }, function (tabs) {
        var ids = [];
        tabs.forEach(function (tab) {
          if (action === 'closelefttabs' && tab.index < currentTabIndex || action === 'closerighttabs' && tab.index > currentTabIndex) {
            ids.push(tab.id);
          }
        });
        chrome.tabs.remove(ids);
      });
    });
  } else if (action === 'togglepin') {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tab) {
      var toggle = !tab[0].pinned;
      chrome.tabs.update(tab[0].id, { pinned: toggle });
    });
  } else if (action === 'copyurl') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      copyToClipboard(tab[0].url);
    });
  } else if (action === 'movetableft') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      if (tab[0].index > 0) {
        chrome.tabs.move(tab[0].id, { 'index': tab[0].index - 1 });
      }
    });
  } else if (action === 'movetabright') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.move(tab[0].id, { 'index': tab[0].index + 1 });
    });
  } else if (action === 'gototab') {
    var createNewTab = function createNewTab() {
      chrome.tabs.create({ url: request.openurl });
    };
    if (request.matchurl) {
      var queryOption = { url: request.matchurl };
      if (request.currentWindow) {
        queryOption.currentWindow = true;
      }
      chrome.tabs.query(queryOption, function (tabs) {
        if (tabs.length > 0) {
          chrome.tabs.update(tabs[0].id, { selected: true });
          chrome.windows.update(tabs[0].windowId, { focused: true });
        } else {
          createNewTab();
        }
      });
    } else {
      createNewTab();
    }
  } else if (action === 'newwindow') {
    chrome.windows.create();
  } else if (action === 'newprivatewindow') {
    chrome.windows.create({ incognito: true });
  } else if (action === 'closewindow') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.windows.remove(tab[0].windowId);
    });
  } else if (action === 'zoomin') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.getZoom(tab[0].id, function (zoomFactor) {
        console.log(zoomFactor);
        chrome.tabs.setZoom(tab[0].id, zoomFactor + 0.1);
      });
    });
  } else if (action === 'zoomout') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.getZoom(tab[0].id, function (zoomFactor) {
        chrome.tabs.setZoom(tab[0].id, zoomFactor - 0.1);
      });
    });
  } else if (action === 'zoomreset') {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
      chrome.tabs.setZoom(tab[0].id, 0);
    });
  } else if (action === 'back') {
    chrome.tabs.executeScript(null, { 'code': 'window.history.back()' });
  } else if (action === 'forward') {
    chrome.tabs.executeScript(null, { 'code': 'window.history.forward()' });
  } else if (action === 'reload') {
    chrome.tabs.executeScript(null, { 'code': 'window.location.reload()' });
  } else if (action === 'top') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollTo(0, 0)' });
  } else if (action === 'bottom') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollTo(0, document.body.scrollHeight)' });
  } else if (action === 'scrollup') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(0,-50)' });
  } else if (action === 'scrollupmore') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(0,-500)' });
  } else if (action === 'scrolldown') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(0,50)' });
  } else if (action === 'scrolldownmore') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(0,500)' });
  } else if (action === 'scrollleft') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(-50,0)' });
  } else if (action === 'scrollleftmore') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(-500,0)' });
  } else if (action === 'scrollright') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(50,0)' });
  } else if (action === 'scrollrightmore') {
    chrome.tabs.executeScript(null, { 'code': 'window.scrollBy(500,0)' });
  } else if (action === 'openbookmark' || action === 'openbookmarknewtab' || action === 'openbookmarkbackgroundtab') {
    chrome.bookmarks.search({ title: request.bookmark }, function (nodes) {
      var openNode = void 0;
      for (var i = nodes.length; i-- > 0;) {
        var node = nodes[i];
        if (node.url && node.title === request.bookmark) {
          openNode = node;
          break;
        }
      }
      if (action === 'openbookmark') {
        chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
          chrome.tabs.update(tab[0].id, { url: decodeURI(openNode.url) });
        });
      } else if (action === 'openbookmarkbackgroundtab') {
        chrome.tabs.create({ url: decodeURI(openNode.url), active: false });
      } else {
        chrome.tabs.create({ url: decodeURI(openNode.url) });
      }
    });
  } else {
    return false;
  }
  return true;
};

chrome.commands.onCommand.addListener(function (command) {
  handleAction(command);
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  var action = request.action;
  if (action === 'getKeys') {
    var currentUrl = request.url;
    var settings = JSON.parse(localStorage.shortkeys);
    var keys = [];
    if (settings.keys.length > 0) {
      settings.keys.forEach(function (key) {
        if (isAllowedSite(key, currentUrl)) {
          keys.push(key);
        }
      });
    }
    sendResponse(keys);
  }
  handleAction(action, request);
});

/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgOTNiMzQ5YTEwNWFmNGIzZDA4MzEiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvYmFja2dyb3VuZC5qcyJdLCJuYW1lcyI6WyJjb3B5VG9DbGlwYm9hcmQiLCJ0ZXh0IiwiY29weURpdiIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImNvbnRlbnRFZGl0YWJsZSIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImlubmVySFRNTCIsInVuc2VsZWN0YWJsZSIsImZvY3VzIiwiZXhlY0NvbW1hbmQiLCJyZW1vdmVDaGlsZCIsInNlbGVjdFRhYiIsImRpcmVjdGlvbiIsImNocm9tZSIsInRhYnMiLCJxdWVyeSIsImN1cnJlbnRXaW5kb3ciLCJsZW5ndGgiLCJhY3RpdmUiLCJjdXJyZW50VGFiSW5BcnJheSIsImN1cnJlbnRUYWIiLCJ0b1NlbGVjdCIsImluZGV4IiwidXBkYXRlIiwiaWQiLCJoaWdobGlnaHRlZCIsImdsb2JUb1JlZ2V4IiwiZ2xvYiIsInRlc3QiLCJSZWdFeHAiLCJyZXBsYWNlIiwic3BlY2lhbENoYXJzIiwicmVnZXhDaGFycyIsImkiLCJjIiwiY2hhckF0IiwicHVzaCIsImluZGV4T2YiLCJqb2luIiwiaXNBbGxvd2VkU2l0ZSIsImtleVNldHRpbmciLCJ1cmwiLCJibGFja2xpc3QiLCJhbGxvd2VkIiwic2l0ZXNBcnJheSIsImZvckVhY2giLCJzaXRlIiwibWF0Y2giLCJoYW5kbGVBY3Rpb24iLCJhY3Rpb24iLCJyZXF1ZXN0IiwiYnJvd3NpbmdEYXRhIiwicmVtb3ZlIiwidGFiIiwiY3JlYXRlIiwic2Vzc2lvbnMiLCJnZXRSZWNlbnRseUNsb3NlZCIsIm1heFJlc3VsdHMiLCJjbG9zZWRUYWIiLCJyZXN0b3JlIiwic2Vzc2lvbnNJZCIsImR1cGxpY2F0ZSIsInBpbm5lZCIsImlkcyIsImN1cnJlbnRUYWJJbmRleCIsInRvZ2dsZSIsIm1vdmUiLCJjcmVhdGVOZXdUYWIiLCJvcGVudXJsIiwibWF0Y2h1cmwiLCJxdWVyeU9wdGlvbiIsInNlbGVjdGVkIiwid2luZG93cyIsIndpbmRvd0lkIiwiZm9jdXNlZCIsImluY29nbml0byIsImdldFpvb20iLCJ6b29tRmFjdG9yIiwiY29uc29sZSIsImxvZyIsInNldFpvb20iLCJleGVjdXRlU2NyaXB0IiwiYm9va21hcmtzIiwic2VhcmNoIiwidGl0bGUiLCJib29rbWFyayIsIm5vZGVzIiwib3Blbk5vZGUiLCJub2RlIiwiZGVjb2RlVVJJIiwiY29tbWFuZHMiLCJvbkNvbW1hbmQiLCJhZGRMaXN0ZW5lciIsImNvbW1hbmQiLCJydW50aW1lIiwib25NZXNzYWdlIiwic2VuZGVyIiwic2VuZFJlc3BvbnNlIiwiY3VycmVudFVybCIsInNldHRpbmdzIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwic2hvcnRrZXlzIiwia2V5cyIsImtleSJdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDN0RBO0FBQ0E7O0FBRUEsSUFBSUEsa0JBQWtCLFNBQWxCQSxlQUFrQixDQUFDQyxJQUFELEVBQVU7QUFDOUIsTUFBSUMsVUFBVUMsU0FBU0MsYUFBVCxDQUF1QixLQUF2QixDQUFkO0FBQ0FGLFVBQVFHLGVBQVIsR0FBMEIsSUFBMUI7QUFDQUYsV0FBU0csSUFBVCxDQUFjQyxXQUFkLENBQTBCTCxPQUExQjtBQUNBQSxVQUFRTSxTQUFSLEdBQW9CUCxJQUFwQjtBQUNBQyxVQUFRTyxZQUFSLEdBQXVCLEtBQXZCO0FBQ0FQLFVBQVFRLEtBQVI7QUFDQVAsV0FBU1EsV0FBVCxDQUFxQixXQUFyQjtBQUNBUixXQUFTUSxXQUFULENBQXFCLE1BQXJCLEVBQTZCLEtBQTdCLEVBQW9DLElBQXBDO0FBQ0FSLFdBQVNHLElBQVQsQ0FBY00sV0FBZCxDQUEwQlYsT0FBMUI7QUFDRCxDQVZEOztBQVlBLElBQUlXLFlBQVksU0FBWkEsU0FBWSxDQUFDQyxTQUFELEVBQWU7QUFDN0JDLFNBQU9DLElBQVAsQ0FBWUMsS0FBWixDQUFrQixFQUFDQyxlQUFlLElBQWhCLEVBQWxCLEVBQXlDLFVBQUNGLElBQUQsRUFBVTtBQUNqRCxRQUFJQSxLQUFLRyxNQUFMLElBQWUsQ0FBbkIsRUFBc0I7QUFDcEI7QUFDRDtBQUNESixXQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFDQyxpQkFBRCxFQUF1QjtBQUM1RSxVQUFJQyxhQUFhRCxrQkFBa0IsQ0FBbEIsQ0FBakI7QUFDQSxVQUFJRSxpQkFBSjtBQUNBLGNBQVFULFNBQVI7QUFDRSxhQUFLLE1BQUw7QUFDRVMscUJBQVdQLEtBQUssQ0FBQ00sV0FBV0UsS0FBWCxHQUFtQixDQUFuQixHQUF1QlIsS0FBS0csTUFBN0IsSUFBdUNILEtBQUtHLE1BQWpELENBQVg7QUFDQTtBQUNGLGFBQUssVUFBTDtBQUNFSSxxQkFBV1AsS0FBSyxDQUFDTSxXQUFXRSxLQUFYLEdBQW1CLENBQW5CLEdBQXVCUixLQUFLRyxNQUE3QixJQUF1Q0gsS0FBS0csTUFBakQsQ0FBWDtBQUNBO0FBQ0YsYUFBSyxPQUFMO0FBQ0VJLHFCQUFXUCxLQUFLLENBQUwsQ0FBWDtBQUNBO0FBQ0YsYUFBSyxNQUFMO0FBQ0VPLHFCQUFXUCxLQUFLQSxLQUFLRyxNQUFMLEdBQWMsQ0FBbkIsQ0FBWDtBQUNBO0FBWko7QUFjQUosYUFBT0MsSUFBUCxDQUFZUyxNQUFaLENBQW1CRixTQUFTRyxFQUE1QixFQUFnQyxFQUFDQyxhQUFhLElBQWQsRUFBaEM7QUFDQVosYUFBT0MsSUFBUCxDQUFZUyxNQUFaLENBQW1CSCxXQUFXSSxFQUE5QixFQUFrQyxFQUFDQyxhQUFhLEtBQWQsRUFBbEM7QUFDRCxLQW5CRDtBQW9CRCxHQXhCRDtBQXlCRCxDQTFCRDs7QUE0QkE7Ozs7OztBQU1BLElBQUlDLGNBQWMsU0FBZEEsV0FBYyxDQUFVQyxJQUFWLEVBQWdCO0FBQ2hDO0FBQ0EsTUFBSSxXQUFXQyxJQUFYLENBQWdCRCxJQUFoQixDQUFKLEVBQTJCLE9BQU8sSUFBSUUsTUFBSixDQUFXRixLQUFLRyxPQUFMLENBQWEsWUFBYixFQUEyQixJQUEzQixDQUFYLENBQVA7O0FBRTNCLE1BQU1DLGVBQWUsaUJBQXJCO0FBQ0EsTUFBSUMsYUFBYSxDQUFDLEdBQUQsQ0FBakI7QUFDQSxPQUFLLElBQUlDLElBQUksQ0FBYixFQUFnQkEsSUFBSU4sS0FBS1YsTUFBekIsRUFBaUMsRUFBRWdCLENBQW5DLEVBQXNDO0FBQ3BDLFFBQUlDLElBQUlQLEtBQUtRLE1BQUwsQ0FBWUYsQ0FBWixDQUFSO0FBQ0EsUUFBSUMsTUFBTSxHQUFWLEVBQWU7QUFDYkYsaUJBQVdJLElBQVgsQ0FBZ0IsSUFBaEI7QUFDRCxLQUZELE1BRU87QUFDTCxVQUFJTCxhQUFhTSxPQUFiLENBQXFCSCxDQUFyQixLQUEyQixDQUEvQixFQUFrQztBQUNoQ0YsbUJBQVdJLElBQVgsQ0FBZ0IsSUFBaEI7QUFDRDtBQUNESixpQkFBV0ksSUFBWCxDQUFnQkYsQ0FBaEI7QUFDRDtBQUNGO0FBQ0RGLGFBQVdJLElBQVgsQ0FBZ0IsR0FBaEI7QUFDQSxTQUFPLElBQUlQLE1BQUosQ0FBV0csV0FBV00sSUFBWCxDQUFnQixFQUFoQixDQUFYLENBQVA7QUFDRCxDQW5CRDs7QUFxQkE7Ozs7Ozs7QUFPQSxJQUFJQyxnQkFBZ0IsU0FBaEJBLGFBQWdCLENBQVVDLFVBQVYsRUFBc0JDLEdBQXRCLEVBQTJCO0FBQzdDLE1BQUlELFdBQVdFLFNBQVgsS0FBeUIsTUFBekIsSUFBbUNGLFdBQVdFLFNBQVgsS0FBeUIsV0FBaEUsRUFBNkU7QUFDM0U7QUFDQSxXQUFPLElBQVA7QUFDRDtBQUNELE1BQUlDLFVBQVVILFdBQVdFLFNBQVgsS0FBeUIsTUFBdkM7QUFDQUYsYUFBV0ksVUFBWCxDQUFzQkMsT0FBdEIsQ0FBOEIsVUFBQ0MsSUFBRCxFQUFVO0FBQ3RDLFFBQUlMLElBQUlNLEtBQUosQ0FBVXJCLFlBQVlvQixJQUFaLENBQVYsQ0FBSixFQUFrQztBQUNoQ0gsZ0JBQVUsQ0FBQ0EsT0FBWDtBQUNEO0FBQ0YsR0FKRDtBQUtBLFNBQU9BLE9BQVA7QUFDRCxDQVpEOztBQWNBLElBQUlLLGVBQWUsU0FBZkEsWUFBZSxDQUFDQyxNQUFELEVBQTBCO0FBQUEsTUFBakJDLE9BQWlCLHVFQUFQLEVBQU87O0FBQzNDLE1BQUlELFdBQVcsZ0JBQWYsRUFBaUM7QUFDL0JwQyxXQUFPc0MsWUFBUCxDQUFvQkMsTUFBcEIsQ0FBMkIsRUFBQyxTQUFTLENBQVYsRUFBM0IsRUFBeUMsRUFBQyxhQUFhLElBQWQsRUFBekM7QUFDRCxHQUZELE1BRU8sSUFBSUgsV0FBVyxZQUFmLEVBQTZCO0FBQ2xDcEMsV0FBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNDLGVBQWUsSUFBaEIsRUFBc0JFLFFBQVEsSUFBOUIsRUFBbEIsRUFBdUQsVUFBQ21DLEdBQUQsRUFBUztBQUM5RHhDLGFBQU9DLElBQVAsQ0FBWXdDLE1BQVosQ0FBbUIsRUFBQ2IsS0FBSyxpQkFBaUJZLElBQUksQ0FBSixFQUFPWixHQUE5QixFQUFuQjtBQUNELEtBRkQ7QUFHRCxHQUpNLE1BSUEsSUFBSVEsV0FBVyxTQUFmLEVBQTBCO0FBQy9CdEMsY0FBVSxNQUFWO0FBQ0QsR0FGTSxNQUVBLElBQUlzQyxXQUFXLFNBQWYsRUFBMEI7QUFDL0J0QyxjQUFVLFVBQVY7QUFDRCxHQUZNLE1BRUEsSUFBSXNDLFdBQVcsVUFBZixFQUEyQjtBQUNoQ3RDLGNBQVUsT0FBVjtBQUNELEdBRk0sTUFFQSxJQUFJc0MsV0FBVyxTQUFmLEVBQTBCO0FBQy9CdEMsY0FBVSxNQUFWO0FBQ0QsR0FGTSxNQUVBLElBQUlzQyxXQUFXLFFBQWYsRUFBeUI7QUFDOUJwQyxXQUFPQyxJQUFQLENBQVl3QyxNQUFaLENBQW1CLEVBQW5CO0FBQ0QsR0FGTSxNQUVBLElBQUlMLFdBQVcsV0FBZixFQUE0QjtBQUNqQ3BDLFdBQU8wQyxRQUFQLENBQWdCQyxpQkFBaEIsQ0FBa0MsRUFBQ0MsWUFBWSxDQUFiLEVBQWxDLEVBQW1ELFVBQVVGLFFBQVYsRUFBb0I7QUFDckUsVUFBSUcsWUFBWUgsU0FBUyxDQUFULENBQWhCO0FBQ0ExQyxhQUFPMEMsUUFBUCxDQUFnQkksT0FBaEIsQ0FBd0JELFVBQVVFLFVBQWxDO0FBQ0QsS0FIRDtBQUlELEdBTE0sTUFLQSxJQUFJWCxXQUFXLFVBQWYsRUFBMkI7QUFDaENwQyxXQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFDbUMsR0FBRCxFQUFTO0FBQzlEeEMsYUFBT0MsSUFBUCxDQUFZc0MsTUFBWixDQUFtQkMsSUFBSSxDQUFKLEVBQU83QixFQUExQjtBQUNELEtBRkQ7QUFHRCxHQUpNLE1BSUEsSUFBSXlCLFdBQVcsVUFBZixFQUEyQjtBQUNoQ3BDLFdBQU9DLElBQVAsQ0FBWUMsS0FBWixDQUFrQixFQUFDQyxlQUFlLElBQWhCLEVBQXNCRSxRQUFRLElBQTlCLEVBQWxCLEVBQXVELFVBQUNtQyxHQUFELEVBQVM7QUFDOUR4QyxhQUFPQyxJQUFQLENBQVkrQyxTQUFaLENBQXNCUixJQUFJLENBQUosRUFBTzdCLEVBQTdCO0FBQ0QsS0FGRDtBQUdELEdBSk0sTUFJQSxJQUFJeUIsV0FBVyxTQUFmLEVBQTBCO0FBQy9CcEMsV0FBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNDLGVBQWUsSUFBaEIsRUFBc0I4QyxRQUFRLEtBQTlCLEVBQXFDNUMsUUFBUSxLQUE3QyxFQUFsQixFQUF1RSxVQUFDSixJQUFELEVBQVU7QUFDL0UsVUFBSWlELE1BQU0sRUFBVjtBQUNBakQsV0FBSytCLE9BQUwsQ0FBYSxVQUFVUSxHQUFWLEVBQWU7QUFDMUJVLFlBQUkzQixJQUFKLENBQVNpQixJQUFJN0IsRUFBYjtBQUNELE9BRkQ7QUFHQVgsYUFBT0MsSUFBUCxDQUFZc0MsTUFBWixDQUFtQlcsR0FBbkI7QUFDRCxLQU5EO0FBT0QsR0FSTSxNQVFBLElBQUlkLFdBQVcsZUFBWCxJQUE4QkEsV0FBVyxnQkFBN0MsRUFBK0Q7QUFDcEVwQyxXQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFVSixJQUFWLEVBQWdCO0FBQ3JFLFVBQUlrRCxrQkFBa0JsRCxLQUFLLENBQUwsRUFBUVEsS0FBOUI7QUFDQVQsYUFBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNDLGVBQWUsSUFBaEIsRUFBc0I4QyxRQUFRLEtBQTlCLEVBQXFDNUMsUUFBUSxLQUE3QyxFQUFsQixFQUF1RSxVQUFDSixJQUFELEVBQVU7QUFDL0UsWUFBSWlELE1BQU0sRUFBVjtBQUNBakQsYUFBSytCLE9BQUwsQ0FBYSxVQUFVUSxHQUFWLEVBQWU7QUFDMUIsY0FBS0osV0FBVyxlQUFYLElBQThCSSxJQUFJL0IsS0FBSixHQUFZMEMsZUFBM0MsSUFDRGYsV0FBVyxnQkFBWCxJQUErQkksSUFBSS9CLEtBQUosR0FBWTBDLGVBRDlDLEVBQ2dFO0FBQzlERCxnQkFBSTNCLElBQUosQ0FBU2lCLElBQUk3QixFQUFiO0FBQ0Q7QUFDRixTQUxEO0FBTUFYLGVBQU9DLElBQVAsQ0FBWXNDLE1BQVosQ0FBbUJXLEdBQW5CO0FBQ0QsT0FURDtBQVVELEtBWkQ7QUFhRCxHQWRNLE1BY0EsSUFBSWQsV0FBVyxXQUFmLEVBQTRCO0FBQ2pDcEMsV0FBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNHLFFBQVEsSUFBVCxFQUFlRixlQUFlLElBQTlCLEVBQWxCLEVBQXVELFVBQUNxQyxHQUFELEVBQVM7QUFDOUQsVUFBSVksU0FBUyxDQUFDWixJQUFJLENBQUosRUFBT1MsTUFBckI7QUFDQWpELGFBQU9DLElBQVAsQ0FBWVMsTUFBWixDQUFtQjhCLElBQUksQ0FBSixFQUFPN0IsRUFBMUIsRUFBOEIsRUFBRXNDLFFBQVFHLE1BQVYsRUFBOUI7QUFDRCxLQUhEO0FBSUQsR0FMTSxNQUtBLElBQUloQixXQUFXLFNBQWYsRUFBMEI7QUFDL0JwQyxXQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFDbUMsR0FBRCxFQUFTO0FBQzlEdkQsc0JBQWdCdUQsSUFBSSxDQUFKLEVBQU9aLEdBQXZCO0FBQ0QsS0FGRDtBQUdELEdBSk0sTUFJQSxJQUFJUSxXQUFXLGFBQWYsRUFBOEI7QUFDbkNwQyxXQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFDbUMsR0FBRCxFQUFTO0FBQzlELFVBQUlBLElBQUksQ0FBSixFQUFPL0IsS0FBUCxHQUFlLENBQW5CLEVBQXNCO0FBQ3BCVCxlQUFPQyxJQUFQLENBQVlvRCxJQUFaLENBQWlCYixJQUFJLENBQUosRUFBTzdCLEVBQXhCLEVBQTRCLEVBQUMsU0FBUzZCLElBQUksQ0FBSixFQUFPL0IsS0FBUCxHQUFlLENBQXpCLEVBQTVCO0FBQ0Q7QUFDRixLQUpEO0FBS0QsR0FOTSxNQU1BLElBQUkyQixXQUFXLGNBQWYsRUFBK0I7QUFDcENwQyxXQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFDbUMsR0FBRCxFQUFTO0FBQzlEeEMsYUFBT0MsSUFBUCxDQUFZb0QsSUFBWixDQUFpQmIsSUFBSSxDQUFKLEVBQU83QixFQUF4QixFQUE0QixFQUFDLFNBQVM2QixJQUFJLENBQUosRUFBTy9CLEtBQVAsR0FBZSxDQUF6QixFQUE1QjtBQUNELEtBRkQ7QUFHRCxHQUpNLE1BSUEsSUFBSTJCLFdBQVcsU0FBZixFQUEwQjtBQUMvQixRQUFJa0IsZUFBZSxTQUFmQSxZQUFlLEdBQU07QUFDdkJ0RCxhQUFPQyxJQUFQLENBQVl3QyxNQUFaLENBQW1CLEVBQUNiLEtBQUtTLFFBQVFrQixPQUFkLEVBQW5CO0FBQ0QsS0FGRDtBQUdBLFFBQUlsQixRQUFRbUIsUUFBWixFQUFzQjtBQUNwQixVQUFJQyxjQUFjLEVBQUM3QixLQUFLUyxRQUFRbUIsUUFBZCxFQUFsQjtBQUNBLFVBQUluQixRQUFRbEMsYUFBWixFQUEyQjtBQUN6QnNELG9CQUFZdEQsYUFBWixHQUE0QixJQUE1QjtBQUNEO0FBQ0RILGFBQU9DLElBQVAsQ0FBWUMsS0FBWixDQUFrQnVELFdBQWxCLEVBQStCLFVBQVV4RCxJQUFWLEVBQWdCO0FBQzdDLFlBQUlBLEtBQUtHLE1BQUwsR0FBYyxDQUFsQixFQUFxQjtBQUNuQkosaUJBQU9DLElBQVAsQ0FBWVMsTUFBWixDQUFtQlQsS0FBSyxDQUFMLEVBQVFVLEVBQTNCLEVBQStCLEVBQUMrQyxVQUFVLElBQVgsRUFBL0I7QUFDQTFELGlCQUFPMkQsT0FBUCxDQUFlakQsTUFBZixDQUFzQlQsS0FBSyxDQUFMLEVBQVEyRCxRQUE5QixFQUF3QyxFQUFDQyxTQUFTLElBQVYsRUFBeEM7QUFDRCxTQUhELE1BR087QUFDTFA7QUFDRDtBQUNGLE9BUEQ7QUFRRCxLQWJELE1BYU87QUFDTEE7QUFDRDtBQUNGLEdBcEJNLE1Bb0JBLElBQUlsQixXQUFXLFdBQWYsRUFBNEI7QUFDakNwQyxXQUFPMkQsT0FBUCxDQUFlbEIsTUFBZjtBQUNELEdBRk0sTUFFQSxJQUFJTCxXQUFXLGtCQUFmLEVBQW1DO0FBQ3hDcEMsV0FBTzJELE9BQVAsQ0FBZWxCLE1BQWYsQ0FBc0IsRUFBQ3FCLFdBQVcsSUFBWixFQUF0QjtBQUNELEdBRk0sTUFFQSxJQUFJMUIsV0FBVyxhQUFmLEVBQThCO0FBQ25DcEMsV0FBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNDLGVBQWUsSUFBaEIsRUFBc0JFLFFBQVEsSUFBOUIsRUFBbEIsRUFBdUQsVUFBQ21DLEdBQUQsRUFBUztBQUM5RHhDLGFBQU8yRCxPQUFQLENBQWVwQixNQUFmLENBQXNCQyxJQUFJLENBQUosRUFBT29CLFFBQTdCO0FBQ0QsS0FGRDtBQUdELEdBSk0sTUFJQSxJQUFJeEIsV0FBVyxRQUFmLEVBQXlCO0FBQzlCcEMsV0FBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNDLGVBQWUsSUFBaEIsRUFBc0JFLFFBQVEsSUFBOUIsRUFBbEIsRUFBdUQsVUFBQ21DLEdBQUQsRUFBUztBQUM5RHhDLGFBQU9DLElBQVAsQ0FBWThELE9BQVosQ0FBb0J2QixJQUFJLENBQUosRUFBTzdCLEVBQTNCLEVBQStCLFVBQUNxRCxVQUFELEVBQWdCO0FBQzdDQyxnQkFBUUMsR0FBUixDQUFZRixVQUFaO0FBQ0FoRSxlQUFPQyxJQUFQLENBQVlrRSxPQUFaLENBQW9CM0IsSUFBSSxDQUFKLEVBQU83QixFQUEzQixFQUErQnFELGFBQWEsR0FBNUM7QUFDRCxPQUhEO0FBSUQsS0FMRDtBQU1ELEdBUE0sTUFPQSxJQUFJNUIsV0FBVyxTQUFmLEVBQTBCO0FBQy9CcEMsV0FBT0MsSUFBUCxDQUFZQyxLQUFaLENBQWtCLEVBQUNDLGVBQWUsSUFBaEIsRUFBc0JFLFFBQVEsSUFBOUIsRUFBbEIsRUFBdUQsVUFBQ21DLEdBQUQsRUFBUztBQUM5RHhDLGFBQU9DLElBQVAsQ0FBWThELE9BQVosQ0FBb0J2QixJQUFJLENBQUosRUFBTzdCLEVBQTNCLEVBQStCLFVBQUNxRCxVQUFELEVBQWdCO0FBQzdDaEUsZUFBT0MsSUFBUCxDQUFZa0UsT0FBWixDQUFvQjNCLElBQUksQ0FBSixFQUFPN0IsRUFBM0IsRUFBK0JxRCxhQUFhLEdBQTVDO0FBQ0QsT0FGRDtBQUdELEtBSkQ7QUFLRCxHQU5NLE1BTUEsSUFBSTVCLFdBQVcsV0FBZixFQUE0QjtBQUNqQ3BDLFdBQU9DLElBQVAsQ0FBWUMsS0FBWixDQUFrQixFQUFDQyxlQUFlLElBQWhCLEVBQXNCRSxRQUFRLElBQTlCLEVBQWxCLEVBQXVELFVBQUNtQyxHQUFELEVBQVM7QUFDOUR4QyxhQUFPQyxJQUFQLENBQVlrRSxPQUFaLENBQW9CM0IsSUFBSSxDQUFKLEVBQU83QixFQUEzQixFQUErQixDQUEvQjtBQUNELEtBRkQ7QUFHRCxHQUpNLE1BSUEsSUFBSXlCLFdBQVcsTUFBZixFQUF1QjtBQUM1QnBDLFdBQU9DLElBQVAsQ0FBWW1FLGFBQVosQ0FBMEIsSUFBMUIsRUFBZ0MsRUFBQyxRQUFRLHVCQUFULEVBQWhDO0FBQ0QsR0FGTSxNQUVBLElBQUloQyxXQUFXLFNBQWYsRUFBMEI7QUFDL0JwQyxXQUFPQyxJQUFQLENBQVltRSxhQUFaLENBQTBCLElBQTFCLEVBQWdDLEVBQUMsUUFBUSwwQkFBVCxFQUFoQztBQUNELEdBRk0sTUFFQSxJQUFJaEMsV0FBVyxRQUFmLEVBQXlCO0FBQzlCcEMsV0FBT0MsSUFBUCxDQUFZbUUsYUFBWixDQUEwQixJQUExQixFQUFnQyxFQUFDLFFBQVEsMEJBQVQsRUFBaEM7QUFDRCxHQUZNLE1BRUEsSUFBSWhDLFdBQVcsS0FBZixFQUFzQjtBQUMzQnBDLFdBQU9DLElBQVAsQ0FBWW1FLGFBQVosQ0FBMEIsSUFBMUIsRUFBZ0MsRUFBQyxRQUFRLHVCQUFULEVBQWhDO0FBQ0QsR0FGTSxNQUVBLElBQUloQyxXQUFXLFFBQWYsRUFBeUI7QUFDOUJwQyxXQUFPQyxJQUFQLENBQVltRSxhQUFaLENBQTBCLElBQTFCLEVBQWdDLEVBQUMsUUFBUSxnREFBVCxFQUFoQztBQUNELEdBRk0sTUFFQSxJQUFJaEMsV0FBVyxVQUFmLEVBQTJCO0FBQ2hDcEMsV0FBT0MsSUFBUCxDQUFZbUUsYUFBWixDQUEwQixJQUExQixFQUFnQyxFQUFDLFFBQVEsd0JBQVQsRUFBaEM7QUFDRCxHQUZNLE1BRUEsSUFBSWhDLFdBQVcsY0FBZixFQUErQjtBQUNwQ3BDLFdBQU9DLElBQVAsQ0FBWW1FLGFBQVosQ0FBMEIsSUFBMUIsRUFBZ0MsRUFBQyxRQUFRLHlCQUFULEVBQWhDO0FBQ0QsR0FGTSxNQUVBLElBQUloQyxXQUFXLFlBQWYsRUFBNkI7QUFDbENwQyxXQUFPQyxJQUFQLENBQVltRSxhQUFaLENBQTBCLElBQTFCLEVBQWdDLEVBQUMsUUFBUSx1QkFBVCxFQUFoQztBQUNELEdBRk0sTUFFQSxJQUFJaEMsV0FBVyxnQkFBZixFQUFpQztBQUN0Q3BDLFdBQU9DLElBQVAsQ0FBWW1FLGFBQVosQ0FBMEIsSUFBMUIsRUFBZ0MsRUFBQyxRQUFRLHdCQUFULEVBQWhDO0FBQ0QsR0FGTSxNQUVBLElBQUloQyxXQUFXLFlBQWYsRUFBNkI7QUFDbENwQyxXQUFPQyxJQUFQLENBQVltRSxhQUFaLENBQTBCLElBQTFCLEVBQWdDLEVBQUMsUUFBUSx3QkFBVCxFQUFoQztBQUNELEdBRk0sTUFFQSxJQUFJaEMsV0FBVyxnQkFBZixFQUFpQztBQUN0Q3BDLFdBQU9DLElBQVAsQ0FBWW1FLGFBQVosQ0FBMEIsSUFBMUIsRUFBZ0MsRUFBQyxRQUFRLHlCQUFULEVBQWhDO0FBQ0QsR0FGTSxNQUVBLElBQUloQyxXQUFXLGFBQWYsRUFBOEI7QUFDbkNwQyxXQUFPQyxJQUFQLENBQVltRSxhQUFaLENBQTBCLElBQTFCLEVBQWdDLEVBQUMsUUFBUSx1QkFBVCxFQUFoQztBQUNELEdBRk0sTUFFQSxJQUFJaEMsV0FBVyxpQkFBZixFQUFrQztBQUN2Q3BDLFdBQU9DLElBQVAsQ0FBWW1FLGFBQVosQ0FBMEIsSUFBMUIsRUFBZ0MsRUFBQyxRQUFRLHdCQUFULEVBQWhDO0FBQ0QsR0FGTSxNQUVBLElBQUloQyxXQUFXLGNBQVgsSUFBNkJBLFdBQVcsb0JBQXhDLElBQWdFQSxXQUFXLDJCQUEvRSxFQUE0RztBQUNqSHBDLFdBQU9xRSxTQUFQLENBQWlCQyxNQUFqQixDQUF3QixFQUFDQyxPQUFPbEMsUUFBUW1DLFFBQWhCLEVBQXhCLEVBQW1ELFVBQVVDLEtBQVYsRUFBaUI7QUFDbEUsVUFBSUMsaUJBQUo7QUFDQSxXQUFLLElBQUl0RCxJQUFJcUQsTUFBTXJFLE1BQW5CLEVBQTJCZ0IsTUFBTSxDQUFqQyxHQUFxQztBQUNuQyxZQUFJdUQsT0FBT0YsTUFBTXJELENBQU4sQ0FBWDtBQUNBLFlBQUl1RCxLQUFLL0MsR0FBTCxJQUFZK0MsS0FBS0osS0FBTCxLQUFlbEMsUUFBUW1DLFFBQXZDLEVBQWlEO0FBQy9DRSxxQkFBV0MsSUFBWDtBQUNBO0FBQ0Q7QUFDRjtBQUNELFVBQUl2QyxXQUFXLGNBQWYsRUFBK0I7QUFDN0JwQyxlQUFPQyxJQUFQLENBQVlDLEtBQVosQ0FBa0IsRUFBQ0MsZUFBZSxJQUFoQixFQUFzQkUsUUFBUSxJQUE5QixFQUFsQixFQUF1RCxVQUFDbUMsR0FBRCxFQUFTO0FBQzlEeEMsaUJBQU9DLElBQVAsQ0FBWVMsTUFBWixDQUFtQjhCLElBQUksQ0FBSixFQUFPN0IsRUFBMUIsRUFBOEIsRUFBQ2lCLEtBQUtnRCxVQUFVRixTQUFTOUMsR0FBbkIsQ0FBTixFQUE5QjtBQUNELFNBRkQ7QUFHRCxPQUpELE1BSU8sSUFBSVEsV0FBVywyQkFBZixFQUE0QztBQUNqRHBDLGVBQU9DLElBQVAsQ0FBWXdDLE1BQVosQ0FBbUIsRUFBQ2IsS0FBS2dELFVBQVVGLFNBQVM5QyxHQUFuQixDQUFOLEVBQStCdkIsUUFBUSxLQUF2QyxFQUFuQjtBQUNELE9BRk0sTUFFQTtBQUNMTCxlQUFPQyxJQUFQLENBQVl3QyxNQUFaLENBQW1CLEVBQUNiLEtBQUtnRCxVQUFVRixTQUFTOUMsR0FBbkIsQ0FBTixFQUFuQjtBQUNEO0FBQ0YsS0FsQkQ7QUFtQkQsR0FwQk0sTUFvQkE7QUFDTCxXQUFPLEtBQVA7QUFDRDtBQUNELFNBQU8sSUFBUDtBQUNELENBdEtEOztBQXdLQTVCLE9BQU82RSxRQUFQLENBQWdCQyxTQUFoQixDQUEwQkMsV0FBMUIsQ0FBc0MsVUFBVUMsT0FBVixFQUFtQjtBQUN2RDdDLGVBQWE2QyxPQUFiO0FBQ0QsQ0FGRDs7QUFJQWhGLE9BQU9pRixPQUFQLENBQWVDLFNBQWYsQ0FBeUJILFdBQXpCLENBQXFDLFVBQVUxQyxPQUFWLEVBQW1COEMsTUFBbkIsRUFBMkJDLFlBQTNCLEVBQXlDO0FBQzVFLE1BQU1oRCxTQUFTQyxRQUFRRCxNQUF2QjtBQUNBLE1BQUlBLFdBQVcsU0FBZixFQUEwQjtBQUN4QixRQUFNaUQsYUFBYWhELFFBQVFULEdBQTNCO0FBQ0EsUUFBSTBELFdBQVdDLEtBQUtDLEtBQUwsQ0FBV0MsYUFBYUMsU0FBeEIsQ0FBZjtBQUNBLFFBQUlDLE9BQU8sRUFBWDtBQUNBLFFBQUlMLFNBQVNLLElBQVQsQ0FBY3ZGLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUJrRixlQUFTSyxJQUFULENBQWMzRCxPQUFkLENBQXNCLFVBQUM0RCxHQUFELEVBQVM7QUFDN0IsWUFBSWxFLGNBQWNrRSxHQUFkLEVBQW1CUCxVQUFuQixDQUFKLEVBQW9DO0FBQ2xDTSxlQUFLcEUsSUFBTCxDQUFVcUUsR0FBVjtBQUNEO0FBQ0YsT0FKRDtBQUtEO0FBQ0RSLGlCQUFhTyxJQUFiO0FBQ0Q7QUFDRHhELGVBQWFDLE1BQWIsRUFBcUJDLE9BQXJCO0FBQ0QsQ0FoQkQsRSIsImZpbGUiOiJiYWNrZ3JvdW5kLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7XG4gXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuIFx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcbiBcdFx0XHRcdGdldDogZ2V0dGVyXG4gXHRcdFx0fSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMSk7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gd2VicGFjay9ib290c3RyYXAgOTNiMzQ5YTEwNWFmNGIzZDA4MzEiLCIndXNlIHN0cmljdCdcbi8qIGdsb2JhbCBsb2NhbFN0b3JhZ2UsIGNocm9tZSAqL1xuXG5sZXQgY29weVRvQ2xpcGJvYXJkID0gKHRleHQpID0+IHtcbiAgbGV0IGNvcHlEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICBjb3B5RGl2LmNvbnRlbnRFZGl0YWJsZSA9IHRydWVcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb3B5RGl2KVxuICBjb3B5RGl2LmlubmVySFRNTCA9IHRleHRcbiAgY29weURpdi51bnNlbGVjdGFibGUgPSAnb2ZmJ1xuICBjb3B5RGl2LmZvY3VzKClcbiAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ1NlbGVjdEFsbCcpXG4gIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdDb3B5JywgZmFsc2UsIG51bGwpXG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoY29weURpdilcbn1cblxubGV0IHNlbGVjdFRhYiA9IChkaXJlY3Rpb24pID0+IHtcbiAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWV9LCAodGFicykgPT4ge1xuICAgIGlmICh0YWJzLmxlbmd0aCA8PSAxKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sIChjdXJyZW50VGFiSW5BcnJheSkgPT4ge1xuICAgICAgbGV0IGN1cnJlbnRUYWIgPSBjdXJyZW50VGFiSW5BcnJheVswXVxuICAgICAgbGV0IHRvU2VsZWN0XG4gICAgICBzd2l0Y2ggKGRpcmVjdGlvbikge1xuICAgICAgICBjYXNlICduZXh0JzpcbiAgICAgICAgICB0b1NlbGVjdCA9IHRhYnNbKGN1cnJlbnRUYWIuaW5kZXggKyAxICsgdGFicy5sZW5ndGgpICUgdGFicy5sZW5ndGhdXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAncHJldmlvdXMnOlxuICAgICAgICAgIHRvU2VsZWN0ID0gdGFic1soY3VycmVudFRhYi5pbmRleCAtIDEgKyB0YWJzLmxlbmd0aCkgJSB0YWJzLmxlbmd0aF1cbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdmaXJzdCc6XG4gICAgICAgICAgdG9TZWxlY3QgPSB0YWJzWzBdXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAnbGFzdCc6XG4gICAgICAgICAgdG9TZWxlY3QgPSB0YWJzW3RhYnMubGVuZ3RoIC0gMV1cbiAgICAgICAgICBicmVha1xuICAgICAgfVxuICAgICAgY2hyb21lLnRhYnMudXBkYXRlKHRvU2VsZWN0LmlkLCB7aGlnaGxpZ2h0ZWQ6IHRydWV9KVxuICAgICAgY2hyb21lLnRhYnMudXBkYXRlKGN1cnJlbnRUYWIuaWQsIHtoaWdobGlnaHRlZDogZmFsc2V9KVxuICAgIH0pXG4gIH0pXG59XG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHRvIGNvbnZlcnQgZ2xvYi93aWxkY2FyZCAqIHN5bnRheCB0byB2YWxpZCBSZWdFeHAgZm9yIFVSTCBjaGVja2luZy5cbiAqXG4gKiBAcGFyYW0gZ2xvYlxuICogQHJldHVybnMge1JlZ0V4cH1cbiAqL1xubGV0IGdsb2JUb1JlZ2V4ID0gZnVuY3Rpb24gKGdsb2IpIHtcbiAgLy8gVXNlIGEgcmVnZXhwIGlmIHRoZSB1cmwgc3RhcnRzIGFuZCBlbmRzIHdpdGggYSBzbGFzaCBgL2BcbiAgaWYgKC9eXFwvLipcXC8kLy50ZXN0KGdsb2IpKSByZXR1cm4gbmV3IFJlZ0V4cChnbG9iLnJlcGxhY2UoL15cXC8oLiopXFwvJC8sICckMScpKVxuXG4gIGNvbnN0IHNwZWNpYWxDaGFycyA9ICdcXFxcXiQqKz8uKCl8e31bXSdcbiAgbGV0IHJlZ2V4Q2hhcnMgPSBbJ14nXVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGdsb2IubGVuZ3RoOyArK2kpIHtcbiAgICBsZXQgYyA9IGdsb2IuY2hhckF0KGkpXG4gICAgaWYgKGMgPT09ICcqJykge1xuICAgICAgcmVnZXhDaGFycy5wdXNoKCcuKicpXG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChzcGVjaWFsQ2hhcnMuaW5kZXhPZihjKSA+PSAwKSB7XG4gICAgICAgIHJlZ2V4Q2hhcnMucHVzaCgnXFxcXCcpXG4gICAgICB9XG4gICAgICByZWdleENoYXJzLnB1c2goYylcbiAgICB9XG4gIH1cbiAgcmVnZXhDaGFycy5wdXNoKCckJylcbiAgcmV0dXJuIG5ldyBSZWdFeHAocmVnZXhDaGFycy5qb2luKCcnKSlcbn1cblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gdG8gZGV0ZXJtaW5lIGlmIHRoZSBjdXJyZW50IHNpdGUgaXMgYmxhY2tsaXN0ZWQgb3Igbm90LlxuICpcbiAqIEBwYXJhbSBrZXlTZXR0aW5nXG4gKiBAcGFyYW0gdXJsXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xubGV0IGlzQWxsb3dlZFNpdGUgPSBmdW5jdGlvbiAoa2V5U2V0dGluZywgdXJsKSB7XG4gIGlmIChrZXlTZXR0aW5nLmJsYWNrbGlzdCAhPT0gJ3RydWUnICYmIGtleVNldHRpbmcuYmxhY2tsaXN0ICE9PSAnd2hpdGVsaXN0Jykge1xuICAgIC8vIFRoaXMgc2hvcnRjdXQgaXMgYWxsb3dlZCBvbiBhbGwgc2l0ZXMgKG5vdCBibGFja2xpc3RlZCBvciB3aGl0ZWxpc3RlZCkuXG4gICAgcmV0dXJuIHRydWVcbiAgfVxuICBsZXQgYWxsb3dlZCA9IGtleVNldHRpbmcuYmxhY2tsaXN0ID09PSAndHJ1ZSdcbiAga2V5U2V0dGluZy5zaXRlc0FycmF5LmZvckVhY2goKHNpdGUpID0+IHtcbiAgICBpZiAodXJsLm1hdGNoKGdsb2JUb1JlZ2V4KHNpdGUpKSkge1xuICAgICAgYWxsb3dlZCA9ICFhbGxvd2VkXG4gICAgfVxuICB9KVxuICByZXR1cm4gYWxsb3dlZFxufVxuXG5sZXQgaGFuZGxlQWN0aW9uID0gKGFjdGlvbiwgcmVxdWVzdCA9IHt9KSA9PiB7XG4gIGlmIChhY3Rpb24gPT09ICdjbGVhcmRvd25sb2FkcycpIHtcbiAgICBjaHJvbWUuYnJvd3NpbmdEYXRhLnJlbW92ZSh7J3NpbmNlJzogMH0sIHsnZG93bmxvYWRzJzogdHJ1ZX0pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAndmlld3NvdXJjZScpIHtcbiAgICBjaHJvbWUudGFicy5xdWVyeSh7Y3VycmVudFdpbmRvdzogdHJ1ZSwgYWN0aXZlOiB0cnVlfSwgKHRhYikgPT4ge1xuICAgICAgY2hyb21lLnRhYnMuY3JlYXRlKHt1cmw6ICd2aWV3LXNvdXJjZTonICsgdGFiWzBdLnVybH0pXG4gICAgfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICduZXh0dGFiJykge1xuICAgIHNlbGVjdFRhYignbmV4dCcpXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAncHJldnRhYicpIHtcbiAgICBzZWxlY3RUYWIoJ3ByZXZpb3VzJylcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdmaXJzdHRhYicpIHtcbiAgICBzZWxlY3RUYWIoJ2ZpcnN0JylcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdsYXN0dGFiJykge1xuICAgIHNlbGVjdFRhYignbGFzdCcpXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnbmV3dGFiJykge1xuICAgIGNocm9tZS50YWJzLmNyZWF0ZSh7fSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdyZW9wZW50YWInKSB7XG4gICAgY2hyb21lLnNlc3Npb25zLmdldFJlY2VudGx5Q2xvc2VkKHttYXhSZXN1bHRzOiAxfSwgZnVuY3Rpb24gKHNlc3Npb25zKSB7XG4gICAgICBsZXQgY2xvc2VkVGFiID0gc2Vzc2lvbnNbMF1cbiAgICAgIGNocm9tZS5zZXNzaW9ucy5yZXN0b3JlKGNsb3NlZFRhYi5zZXNzaW9uc0lkKVxuICAgIH0pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnY2xvc2V0YWInKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sICh0YWIpID0+IHtcbiAgICAgIGNocm9tZS50YWJzLnJlbW92ZSh0YWJbMF0uaWQpXG4gICAgfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdjbG9uZXRhYicpIHtcbiAgICBjaHJvbWUudGFicy5xdWVyeSh7Y3VycmVudFdpbmRvdzogdHJ1ZSwgYWN0aXZlOiB0cnVlfSwgKHRhYikgPT4ge1xuICAgICAgY2hyb21lLnRhYnMuZHVwbGljYXRlKHRhYlswXS5pZClcbiAgICB9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ29ubHl0YWInKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIHBpbm5lZDogZmFsc2UsIGFjdGl2ZTogZmFsc2V9LCAodGFicykgPT4ge1xuICAgICAgbGV0IGlkcyA9IFtdXG4gICAgICB0YWJzLmZvckVhY2goZnVuY3Rpb24gKHRhYikge1xuICAgICAgICBpZHMucHVzaCh0YWIuaWQpXG4gICAgICB9KVxuICAgICAgY2hyb21lLnRhYnMucmVtb3ZlKGlkcylcbiAgICB9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2Nsb3NlbGVmdHRhYnMnIHx8IGFjdGlvbiA9PT0gJ2Nsb3NlcmlnaHR0YWJzJykge1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHtjdXJyZW50V2luZG93OiB0cnVlLCBhY3RpdmU6IHRydWV9LCBmdW5jdGlvbiAodGFicykge1xuICAgICAgbGV0IGN1cnJlbnRUYWJJbmRleCA9IHRhYnNbMF0uaW5kZXhcbiAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHtjdXJyZW50V2luZG93OiB0cnVlLCBwaW5uZWQ6IGZhbHNlLCBhY3RpdmU6IGZhbHNlfSwgKHRhYnMpID0+IHtcbiAgICAgICAgbGV0IGlkcyA9IFtdXG4gICAgICAgIHRhYnMuZm9yRWFjaChmdW5jdGlvbiAodGFiKSB7XG4gICAgICAgICAgaWYgKChhY3Rpb24gPT09ICdjbG9zZWxlZnR0YWJzJyAmJiB0YWIuaW5kZXggPCBjdXJyZW50VGFiSW5kZXgpIHx8XG4gICAgICAgICAgICAoYWN0aW9uID09PSAnY2xvc2VyaWdodHRhYnMnICYmIHRhYi5pbmRleCA+IGN1cnJlbnRUYWJJbmRleCkpIHtcbiAgICAgICAgICAgIGlkcy5wdXNoKHRhYi5pZClcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIGNocm9tZS50YWJzLnJlbW92ZShpZHMpXG4gICAgICB9KVxuICAgIH0pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAndG9nZ2xlcGluJykge1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHthY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWV9LCAodGFiKSA9PiB7XG4gICAgICBsZXQgdG9nZ2xlID0gIXRhYlswXS5waW5uZWRcbiAgICAgIGNocm9tZS50YWJzLnVwZGF0ZSh0YWJbMF0uaWQsIHsgcGlubmVkOiB0b2dnbGUgfSlcbiAgICB9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2NvcHl1cmwnKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sICh0YWIpID0+IHtcbiAgICAgIGNvcHlUb0NsaXBib2FyZCh0YWJbMF0udXJsKVxuICAgIH0pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnbW92ZXRhYmxlZnQnKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sICh0YWIpID0+IHtcbiAgICAgIGlmICh0YWJbMF0uaW5kZXggPiAwKSB7XG4gICAgICAgIGNocm9tZS50YWJzLm1vdmUodGFiWzBdLmlkLCB7J2luZGV4JzogdGFiWzBdLmluZGV4IC0gMX0pXG4gICAgICB9XG4gICAgfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdtb3ZldGFicmlnaHQnKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sICh0YWIpID0+IHtcbiAgICAgIGNocm9tZS50YWJzLm1vdmUodGFiWzBdLmlkLCB7J2luZGV4JzogdGFiWzBdLmluZGV4ICsgMX0pXG4gICAgfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdnb3RvdGFiJykge1xuICAgIGxldCBjcmVhdGVOZXdUYWIgPSAoKSA9PiB7XG4gICAgICBjaHJvbWUudGFicy5jcmVhdGUoe3VybDogcmVxdWVzdC5vcGVudXJsfSlcbiAgICB9XG4gICAgaWYgKHJlcXVlc3QubWF0Y2h1cmwpIHtcbiAgICAgIGxldCBxdWVyeU9wdGlvbiA9IHt1cmw6IHJlcXVlc3QubWF0Y2h1cmx9XG4gICAgICBpZiAocmVxdWVzdC5jdXJyZW50V2luZG93KSB7XG4gICAgICAgIHF1ZXJ5T3B0aW9uLmN1cnJlbnRXaW5kb3cgPSB0cnVlXG4gICAgICB9XG4gICAgICBjaHJvbWUudGFicy5xdWVyeShxdWVyeU9wdGlvbiwgZnVuY3Rpb24gKHRhYnMpIHtcbiAgICAgICAgaWYgKHRhYnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGNocm9tZS50YWJzLnVwZGF0ZSh0YWJzWzBdLmlkLCB7c2VsZWN0ZWQ6IHRydWV9KVxuICAgICAgICAgIGNocm9tZS53aW5kb3dzLnVwZGF0ZSh0YWJzWzBdLndpbmRvd0lkLCB7Zm9jdXNlZDogdHJ1ZX0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY3JlYXRlTmV3VGFiKClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgY3JlYXRlTmV3VGFiKClcbiAgICB9XG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnbmV3d2luZG93Jykge1xuICAgIGNocm9tZS53aW5kb3dzLmNyZWF0ZSgpXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnbmV3cHJpdmF0ZXdpbmRvdycpIHtcbiAgICBjaHJvbWUud2luZG93cy5jcmVhdGUoe2luY29nbml0bzogdHJ1ZX0pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnY2xvc2V3aW5kb3cnKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sICh0YWIpID0+IHtcbiAgICAgIGNocm9tZS53aW5kb3dzLnJlbW92ZSh0YWJbMF0ud2luZG93SWQpXG4gICAgfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICd6b29taW4nKSB7XG4gICAgY2hyb21lLnRhYnMucXVlcnkoe2N1cnJlbnRXaW5kb3c6IHRydWUsIGFjdGl2ZTogdHJ1ZX0sICh0YWIpID0+IHtcbiAgICAgIGNocm9tZS50YWJzLmdldFpvb20odGFiWzBdLmlkLCAoem9vbUZhY3RvcikgPT4ge1xuICAgICAgICBjb25zb2xlLmxvZyh6b29tRmFjdG9yKVxuICAgICAgICBjaHJvbWUudGFicy5zZXRab29tKHRhYlswXS5pZCwgem9vbUZhY3RvciArIDAuMSlcbiAgICAgIH0pXG4gICAgfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICd6b29tb3V0Jykge1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHtjdXJyZW50V2luZG93OiB0cnVlLCBhY3RpdmU6IHRydWV9LCAodGFiKSA9PiB7XG4gICAgICBjaHJvbWUudGFicy5nZXRab29tKHRhYlswXS5pZCwgKHpvb21GYWN0b3IpID0+IHtcbiAgICAgICAgY2hyb21lLnRhYnMuc2V0Wm9vbSh0YWJbMF0uaWQsIHpvb21GYWN0b3IgLSAwLjEpXG4gICAgICB9KVxuICAgIH0pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnem9vbXJlc2V0Jykge1xuICAgIGNocm9tZS50YWJzLnF1ZXJ5KHtjdXJyZW50V2luZG93OiB0cnVlLCBhY3RpdmU6IHRydWV9LCAodGFiKSA9PiB7XG4gICAgICBjaHJvbWUudGFicy5zZXRab29tKHRhYlswXS5pZCwgMClcbiAgICB9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2JhY2snKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93Lmhpc3RvcnkuYmFjaygpJ30pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnZm9yd2FyZCcpIHtcbiAgICBjaHJvbWUudGFicy5leGVjdXRlU2NyaXB0KG51bGwsIHsnY29kZSc6ICd3aW5kb3cuaGlzdG9yeS5mb3J3YXJkKCknfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdyZWxvYWQnKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpJ30pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAndG9wJykge1xuICAgIGNocm9tZS50YWJzLmV4ZWN1dGVTY3JpcHQobnVsbCwgeydjb2RlJzogJ3dpbmRvdy5zY3JvbGxUbygwLCAwKSd9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2JvdHRvbScpIHtcbiAgICBjaHJvbWUudGFicy5leGVjdXRlU2NyaXB0KG51bGwsIHsnY29kZSc6ICd3aW5kb3cuc2Nyb2xsVG8oMCwgZG9jdW1lbnQuYm9keS5zY3JvbGxIZWlnaHQpJ30pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnc2Nyb2xsdXAnKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93LnNjcm9sbEJ5KDAsLTUwKSd9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ3Njcm9sbHVwbW9yZScpIHtcbiAgICBjaHJvbWUudGFicy5leGVjdXRlU2NyaXB0KG51bGwsIHsnY29kZSc6ICd3aW5kb3cuc2Nyb2xsQnkoMCwtNTAwKSd9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ3Njcm9sbGRvd24nKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93LnNjcm9sbEJ5KDAsNTApJ30pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnc2Nyb2xsZG93bm1vcmUnKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93LnNjcm9sbEJ5KDAsNTAwKSd9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ3Njcm9sbGxlZnQnKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93LnNjcm9sbEJ5KC01MCwwKSd9KVxuICB9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ3Njcm9sbGxlZnRtb3JlJykge1xuICAgIGNocm9tZS50YWJzLmV4ZWN1dGVTY3JpcHQobnVsbCwgeydjb2RlJzogJ3dpbmRvdy5zY3JvbGxCeSgtNTAwLDApJ30pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnc2Nyb2xscmlnaHQnKSB7XG4gICAgY2hyb21lLnRhYnMuZXhlY3V0ZVNjcmlwdChudWxsLCB7J2NvZGUnOiAnd2luZG93LnNjcm9sbEJ5KDUwLDApJ30pXG4gIH0gZWxzZSBpZiAoYWN0aW9uID09PSAnc2Nyb2xscmlnaHRtb3JlJykge1xuICAgIGNocm9tZS50YWJzLmV4ZWN1dGVTY3JpcHQobnVsbCwgeydjb2RlJzogJ3dpbmRvdy5zY3JvbGxCeSg1MDAsMCknfSlcbiAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdvcGVuYm9va21hcmsnIHx8IGFjdGlvbiA9PT0gJ29wZW5ib29rbWFya25ld3RhYicgfHwgYWN0aW9uID09PSAnb3BlbmJvb2ttYXJrYmFja2dyb3VuZHRhYicpIHtcbiAgICBjaHJvbWUuYm9va21hcmtzLnNlYXJjaCh7dGl0bGU6IHJlcXVlc3QuYm9va21hcmt9LCBmdW5jdGlvbiAobm9kZXMpIHtcbiAgICAgIGxldCBvcGVuTm9kZVxuICAgICAgZm9yIChsZXQgaSA9IG5vZGVzLmxlbmd0aDsgaS0tID4gMDspIHtcbiAgICAgICAgbGV0IG5vZGUgPSBub2Rlc1tpXVxuICAgICAgICBpZiAobm9kZS51cmwgJiYgbm9kZS50aXRsZSA9PT0gcmVxdWVzdC5ib29rbWFyaykge1xuICAgICAgICAgIG9wZW5Ob2RlID0gbm9kZVxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChhY3Rpb24gPT09ICdvcGVuYm9va21hcmsnKSB7XG4gICAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHtjdXJyZW50V2luZG93OiB0cnVlLCBhY3RpdmU6IHRydWV9LCAodGFiKSA9PiB7XG4gICAgICAgICAgY2hyb21lLnRhYnMudXBkYXRlKHRhYlswXS5pZCwge3VybDogZGVjb2RlVVJJKG9wZW5Ob2RlLnVybCl9KVxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIGlmIChhY3Rpb24gPT09ICdvcGVuYm9va21hcmtiYWNrZ3JvdW5kdGFiJykge1xuICAgICAgICBjaHJvbWUudGFicy5jcmVhdGUoe3VybDogZGVjb2RlVVJJKG9wZW5Ob2RlLnVybCksIGFjdGl2ZTogZmFsc2V9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2hyb21lLnRhYnMuY3JlYXRlKHt1cmw6IGRlY29kZVVSSShvcGVuTm9kZS51cmwpfSlcbiAgICAgIH1cbiAgICB9KVxuICB9IGVsc2Uge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG4gIHJldHVybiB0cnVlXG59XG5cbmNocm9tZS5jb21tYW5kcy5vbkNvbW1hbmQuYWRkTGlzdGVuZXIoZnVuY3Rpb24gKGNvbW1hbmQpIHtcbiAgaGFuZGxlQWN0aW9uKGNvbW1hbmQpXG59KVxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoZnVuY3Rpb24gKHJlcXVlc3QsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSB7XG4gIGNvbnN0IGFjdGlvbiA9IHJlcXVlc3QuYWN0aW9uXG4gIGlmIChhY3Rpb24gPT09ICdnZXRLZXlzJykge1xuICAgIGNvbnN0IGN1cnJlbnRVcmwgPSByZXF1ZXN0LnVybFxuICAgIGxldCBzZXR0aW5ncyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLnNob3J0a2V5cylcbiAgICBsZXQga2V5cyA9IFtdXG4gICAgaWYgKHNldHRpbmdzLmtleXMubGVuZ3RoID4gMCkge1xuICAgICAgc2V0dGluZ3Mua2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgaWYgKGlzQWxsb3dlZFNpdGUoa2V5LCBjdXJyZW50VXJsKSkge1xuICAgICAgICAgIGtleXMucHVzaChrZXkpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICAgIHNlbmRSZXNwb25zZShrZXlzKVxuICB9XG4gIGhhbmRsZUFjdGlvbihhY3Rpb24sIHJlcXVlc3QpXG59KVxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4vYXBwL3NjcmlwdHMvYmFja2dyb3VuZC5qcyJdLCJzb3VyY2VSb290IjoiIn0=