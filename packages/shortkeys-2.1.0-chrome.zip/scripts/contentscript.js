/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(4);


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/* global Mousetrap */

var Shortkeys = {};
Shortkeys.keys = [];

/**
 * Helper function for fetching the full key shortcut config given a keyboard combo.
 *
 * @param keyCombo
 */
Shortkeys.fetchConfig = function (keyCombo) {
  var returnKey = false;
  if (Shortkeys.keys.length > 0) {
    Shortkeys.keys.forEach(function (key) {
      if (key.key === keyCombo) {
        returnKey = key;
      }
    });
  }
  return returnKey;
};

/**
 * Given a key shortcut config item, carry out the action configured for it.
 * This is what happens when the user triggers the shortcut.
 *
 * @param keySetting
 */
Shortkeys.doAction = function (keySetting) {
  var action = keySetting.action;
  var message = {};
  for (var attribute in keySetting) {
    message[attribute] = keySetting[attribute];
  }

  // It's a little hacky, but we have to insert JS this way rather than using executeScript() from the background JS,
  // because this way we have access to the libraries that exist on the page on any given site, such as jQuery.
  if (action === 'javascript') {
    var script = document.createElement('script');
    script.textContent = keySetting.code;
    document.body.appendChild(script);
    document.body.removeChild(script);
    return;
  }

  if (action === 'buttonnexttab') {
    if (keySetting.button) {
      document.querySelector(keySetting.button).click();
    }
    message.action = 'nexttab';
  }

  chrome.runtime.sendMessage(message);
};

/**
 * Given a key shortcut config item, ask if the current site is allowed, and if so,
 * activate the shortcut.
 *
 * @param keySetting
 */
Shortkeys.activateKey = function (keySetting) {
  var action = function action() {
    Shortkeys.doAction(keySetting);
    return false;
  };
  Mousetrap.bind(keySetting.key, action);
};

/**
 * Overrides the default stopCallback from Mousetrap so that we can customize
 * a few things, such as not using the "whitelist inputs with the mousetrap class"
 * functionality and wire up the "activate in form inputs" checkbox.
 *
 * @param e
 * @param element
 * @param combo
 */
Mousetrap.prototype.stopCallback = function (e, element, combo) {
  var keySetting = Shortkeys.fetchConfig(combo);

  if (element.classList.contains('mousetrap')) {
    // We're not using the 'mousetrap' class functionality, which allows
    // you to whitelist elements, so if we come across elements with that class
    // then we can assume that they are provided by the site itself, not by
    // us, so we don't activate Shortkeys in that case, to prevent conflicts.
    // This fixes the chat box in Twitch.tv for example.
    return true;
  } else if (!keySetting.activeInInputs) {
    // If the user has not checked "Also allow in form inputs" for this shortcut,
    // then we cut out of the user is in a form input.
    return element.tagName === 'INPUT' || element.tagName === 'SELECT' || element.tagName === 'TEXTAREA' || element.isContentEditable;
  } else {
    // The user HAS checked "Also allow in form inputs" for this shortcut so we
    // have no reason to stop it from triggering.
    return false;
  }
};

/**
 * Fetches the Shortkeys configuration object and wires up each configured shortcut.
 */
chrome.runtime.sendMessage({ action: 'getKeys', url: document.URL }, function (response) {
  if (response) {
    Shortkeys.keys = response;
    if (Shortkeys.keys.length > 0) {
      Shortkeys.keys.forEach(function (key) {
        Shortkeys.activateKey(key);
      });
    }
  }
});

/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgOTNiMzQ5YTEwNWFmNGIzZDA4MzEiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvY29udGVudHNjcmlwdC5qcyJdLCJuYW1lcyI6WyJTaG9ydGtleXMiLCJrZXlzIiwiZmV0Y2hDb25maWciLCJrZXlDb21ibyIsInJldHVybktleSIsImxlbmd0aCIsImZvckVhY2giLCJrZXkiLCJkb0FjdGlvbiIsImtleVNldHRpbmciLCJhY3Rpb24iLCJtZXNzYWdlIiwiYXR0cmlidXRlIiwic2NyaXB0IiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwidGV4dENvbnRlbnQiLCJjb2RlIiwiYm9keSIsImFwcGVuZENoaWxkIiwicmVtb3ZlQ2hpbGQiLCJidXR0b24iLCJxdWVyeVNlbGVjdG9yIiwiY2xpY2siLCJjaHJvbWUiLCJydW50aW1lIiwic2VuZE1lc3NhZ2UiLCJhY3RpdmF0ZUtleSIsIk1vdXNldHJhcCIsImJpbmQiLCJwcm90b3R5cGUiLCJzdG9wQ2FsbGJhY2siLCJlIiwiZWxlbWVudCIsImNvbWJvIiwiY2xhc3NMaXN0IiwiY29udGFpbnMiLCJhY3RpdmVJbklucHV0cyIsInRhZ05hbWUiLCJpc0NvbnRlbnRFZGl0YWJsZSIsInVybCIsIlVSTCIsInJlc3BvbnNlIl0sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1DQUEyQiwwQkFBMEIsRUFBRTtBQUN2RCx5Q0FBaUMsZUFBZTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4REFBc0QsK0RBQStEOztBQUVySDtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdEQTtBQUNBOztBQUVBLElBQUlBLFlBQVksRUFBaEI7QUFDQUEsVUFBVUMsSUFBVixHQUFpQixFQUFqQjs7QUFFQTs7Ozs7QUFLQUQsVUFBVUUsV0FBVixHQUF3QixVQUFDQyxRQUFELEVBQWM7QUFDcEMsTUFBSUMsWUFBWSxLQUFoQjtBQUNBLE1BQUlKLFVBQVVDLElBQVYsQ0FBZUksTUFBZixHQUF3QixDQUE1QixFQUErQjtBQUM3QkwsY0FBVUMsSUFBVixDQUFlSyxPQUFmLENBQXVCLFVBQUNDLEdBQUQsRUFBUztBQUM5QixVQUFJQSxJQUFJQSxHQUFKLEtBQVlKLFFBQWhCLEVBQTBCO0FBQ3hCQyxvQkFBWUcsR0FBWjtBQUNEO0FBQ0YsS0FKRDtBQUtEO0FBQ0QsU0FBT0gsU0FBUDtBQUNELENBVkQ7O0FBWUE7Ozs7OztBQU1BSixVQUFVUSxRQUFWLEdBQXFCLFVBQUNDLFVBQUQsRUFBZ0I7QUFDbkMsTUFBSUMsU0FBU0QsV0FBV0MsTUFBeEI7QUFDQSxNQUFJQyxVQUFVLEVBQWQ7QUFDQSxPQUFLLElBQUlDLFNBQVQsSUFBc0JILFVBQXRCLEVBQWtDO0FBQ2hDRSxZQUFRQyxTQUFSLElBQXFCSCxXQUFXRyxTQUFYLENBQXJCO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBLE1BQUlGLFdBQVcsWUFBZixFQUE2QjtBQUMzQixRQUFJRyxTQUFTQyxTQUFTQyxhQUFULENBQXVCLFFBQXZCLENBQWI7QUFDQUYsV0FBT0csV0FBUCxHQUFxQlAsV0FBV1EsSUFBaEM7QUFDQUgsYUFBU0ksSUFBVCxDQUFjQyxXQUFkLENBQTBCTixNQUExQjtBQUNBQyxhQUFTSSxJQUFULENBQWNFLFdBQWQsQ0FBMEJQLE1BQTFCO0FBQ0E7QUFDRDs7QUFFRCxNQUFJSCxXQUFXLGVBQWYsRUFBZ0M7QUFDOUIsUUFBSUQsV0FBV1ksTUFBZixFQUF1QjtBQUNyQlAsZUFBU1EsYUFBVCxDQUF1QmIsV0FBV1ksTUFBbEMsRUFBMENFLEtBQTFDO0FBQ0Q7QUFDRFosWUFBUUQsTUFBUixHQUFpQixTQUFqQjtBQUNEOztBQUVEYyxTQUFPQyxPQUFQLENBQWVDLFdBQWYsQ0FBMkJmLE9BQTNCO0FBQ0QsQ0F6QkQ7O0FBMkJBOzs7Ozs7QUFNQVgsVUFBVTJCLFdBQVYsR0FBd0IsVUFBQ2xCLFVBQUQsRUFBZ0I7QUFDdEMsTUFBSUMsU0FBUyxTQUFUQSxNQUFTLEdBQVk7QUFDdkJWLGNBQVVRLFFBQVYsQ0FBbUJDLFVBQW5CO0FBQ0EsV0FBTyxLQUFQO0FBQ0QsR0FIRDtBQUlBbUIsWUFBVUMsSUFBVixDQUFlcEIsV0FBV0YsR0FBMUIsRUFBK0JHLE1BQS9CO0FBQ0QsQ0FORDs7QUFRQTs7Ozs7Ozs7O0FBU0FrQixVQUFVRSxTQUFWLENBQW9CQyxZQUFwQixHQUFtQyxVQUFVQyxDQUFWLEVBQWFDLE9BQWIsRUFBc0JDLEtBQXRCLEVBQTZCO0FBQzlELE1BQUl6QixhQUFhVCxVQUFVRSxXQUFWLENBQXNCZ0MsS0FBdEIsQ0FBakI7O0FBRUEsTUFBSUQsUUFBUUUsU0FBUixDQUFrQkMsUUFBbEIsQ0FBMkIsV0FBM0IsQ0FBSixFQUE2QztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBTyxJQUFQO0FBQ0QsR0FQRCxNQU9PLElBQUksQ0FBQzNCLFdBQVc0QixjQUFoQixFQUFnQztBQUNyQztBQUNBO0FBQ0EsV0FBT0osUUFBUUssT0FBUixLQUFvQixPQUFwQixJQUNMTCxRQUFRSyxPQUFSLEtBQW9CLFFBRGYsSUFFTEwsUUFBUUssT0FBUixLQUFvQixVQUZmLElBR0xMLFFBQVFNLGlCQUhWO0FBSUQsR0FQTSxNQU9BO0FBQ0w7QUFDQTtBQUNBLFdBQU8sS0FBUDtBQUNEO0FBQ0YsQ0F0QkQ7O0FBd0JBOzs7QUFHQWYsT0FBT0MsT0FBUCxDQUFlQyxXQUFmLENBQTJCLEVBQUNoQixRQUFRLFNBQVQsRUFBb0I4QixLQUFLMUIsU0FBUzJCLEdBQWxDLEVBQTNCLEVBQW1FLFVBQVVDLFFBQVYsRUFBb0I7QUFDckYsTUFBSUEsUUFBSixFQUFjO0FBQ1oxQyxjQUFVQyxJQUFWLEdBQWlCeUMsUUFBakI7QUFDQSxRQUFJMUMsVUFBVUMsSUFBVixDQUFlSSxNQUFmLEdBQXdCLENBQTVCLEVBQStCO0FBQzdCTCxnQkFBVUMsSUFBVixDQUFlSyxPQUFmLENBQXVCLFVBQUNDLEdBQUQsRUFBUztBQUM5QlAsa0JBQVUyQixXQUFWLENBQXNCcEIsR0FBdEI7QUFDRCxPQUZEO0FBR0Q7QUFDRjtBQUNGLENBVEQsRSIsImZpbGUiOiJjb250ZW50c2NyaXB0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7XG4gXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuIFx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcbiBcdFx0XHRcdGdldDogZ2V0dGVyXG4gXHRcdFx0fSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMyk7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gd2VicGFjay9ib290c3RyYXAgOTNiMzQ5YTEwNWFmNGIzZDA4MzEiLCIndXNlIHN0cmljdCdcbi8qIGdsb2JhbCBNb3VzZXRyYXAgKi9cblxubGV0IFNob3J0a2V5cyA9IHt9XG5TaG9ydGtleXMua2V5cyA9IFtdXG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIGZvciBmZXRjaGluZyB0aGUgZnVsbCBrZXkgc2hvcnRjdXQgY29uZmlnIGdpdmVuIGEga2V5Ym9hcmQgY29tYm8uXG4gKlxuICogQHBhcmFtIGtleUNvbWJvXG4gKi9cblNob3J0a2V5cy5mZXRjaENvbmZpZyA9IChrZXlDb21ibykgPT4ge1xuICBsZXQgcmV0dXJuS2V5ID0gZmFsc2VcbiAgaWYgKFNob3J0a2V5cy5rZXlzLmxlbmd0aCA+IDApIHtcbiAgICBTaG9ydGtleXMua2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGlmIChrZXkua2V5ID09PSBrZXlDb21ibykge1xuICAgICAgICByZXR1cm5LZXkgPSBrZXlcbiAgICAgIH1cbiAgICB9KVxuICB9XG4gIHJldHVybiByZXR1cm5LZXlcbn1cblxuLyoqXG4gKiBHaXZlbiBhIGtleSBzaG9ydGN1dCBjb25maWcgaXRlbSwgY2Fycnkgb3V0IHRoZSBhY3Rpb24gY29uZmlndXJlZCBmb3IgaXQuXG4gKiBUaGlzIGlzIHdoYXQgaGFwcGVucyB3aGVuIHRoZSB1c2VyIHRyaWdnZXJzIHRoZSBzaG9ydGN1dC5cbiAqXG4gKiBAcGFyYW0ga2V5U2V0dGluZ1xuICovXG5TaG9ydGtleXMuZG9BY3Rpb24gPSAoa2V5U2V0dGluZykgPT4ge1xuICBsZXQgYWN0aW9uID0ga2V5U2V0dGluZy5hY3Rpb25cbiAgbGV0IG1lc3NhZ2UgPSB7fVxuICBmb3IgKGxldCBhdHRyaWJ1dGUgaW4ga2V5U2V0dGluZykge1xuICAgIG1lc3NhZ2VbYXR0cmlidXRlXSA9IGtleVNldHRpbmdbYXR0cmlidXRlXVxuICB9XG5cbiAgLy8gSXQncyBhIGxpdHRsZSBoYWNreSwgYnV0IHdlIGhhdmUgdG8gaW5zZXJ0IEpTIHRoaXMgd2F5IHJhdGhlciB0aGFuIHVzaW5nIGV4ZWN1dGVTY3JpcHQoKSBmcm9tIHRoZSBiYWNrZ3JvdW5kIEpTLFxuICAvLyBiZWNhdXNlIHRoaXMgd2F5IHdlIGhhdmUgYWNjZXNzIHRvIHRoZSBsaWJyYXJpZXMgdGhhdCBleGlzdCBvbiB0aGUgcGFnZSBvbiBhbnkgZ2l2ZW4gc2l0ZSwgc3VjaCBhcyBqUXVlcnkuXG4gIGlmIChhY3Rpb24gPT09ICdqYXZhc2NyaXB0Jykge1xuICAgIGxldCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKVxuICAgIHNjcmlwdC50ZXh0Q29udGVudCA9IGtleVNldHRpbmcuY29kZVxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoc2NyaXB0KVxuICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoc2NyaXB0KVxuICAgIHJldHVyblxuICB9XG5cbiAgaWYgKGFjdGlvbiA9PT0gJ2J1dHRvbm5leHR0YWInKSB7XG4gICAgaWYgKGtleVNldHRpbmcuYnV0dG9uKSB7XG4gICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGtleVNldHRpbmcuYnV0dG9uKS5jbGljaygpXG4gICAgfVxuICAgIG1lc3NhZ2UuYWN0aW9uID0gJ25leHR0YWInXG4gIH1cblxuICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtZXNzYWdlKVxufVxuXG4vKipcbiAqIEdpdmVuIGEga2V5IHNob3J0Y3V0IGNvbmZpZyBpdGVtLCBhc2sgaWYgdGhlIGN1cnJlbnQgc2l0ZSBpcyBhbGxvd2VkLCBhbmQgaWYgc28sXG4gKiBhY3RpdmF0ZSB0aGUgc2hvcnRjdXQuXG4gKlxuICogQHBhcmFtIGtleVNldHRpbmdcbiAqL1xuU2hvcnRrZXlzLmFjdGl2YXRlS2V5ID0gKGtleVNldHRpbmcpID0+IHtcbiAgbGV0IGFjdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICBTaG9ydGtleXMuZG9BY3Rpb24oa2V5U2V0dGluZylcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuICBNb3VzZXRyYXAuYmluZChrZXlTZXR0aW5nLmtleSwgYWN0aW9uKVxufVxuXG4vKipcbiAqIE92ZXJyaWRlcyB0aGUgZGVmYXVsdCBzdG9wQ2FsbGJhY2sgZnJvbSBNb3VzZXRyYXAgc28gdGhhdCB3ZSBjYW4gY3VzdG9taXplXG4gKiBhIGZldyB0aGluZ3MsIHN1Y2ggYXMgbm90IHVzaW5nIHRoZSBcIndoaXRlbGlzdCBpbnB1dHMgd2l0aCB0aGUgbW91c2V0cmFwIGNsYXNzXCJcbiAqIGZ1bmN0aW9uYWxpdHkgYW5kIHdpcmUgdXAgdGhlIFwiYWN0aXZhdGUgaW4gZm9ybSBpbnB1dHNcIiBjaGVja2JveC5cbiAqXG4gKiBAcGFyYW0gZVxuICogQHBhcmFtIGVsZW1lbnRcbiAqIEBwYXJhbSBjb21ib1xuICovXG5Nb3VzZXRyYXAucHJvdG90eXBlLnN0b3BDYWxsYmFjayA9IGZ1bmN0aW9uIChlLCBlbGVtZW50LCBjb21ibykge1xuICBsZXQga2V5U2V0dGluZyA9IFNob3J0a2V5cy5mZXRjaENvbmZpZyhjb21ibylcblxuICBpZiAoZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoJ21vdXNldHJhcCcpKSB7XG4gICAgLy8gV2UncmUgbm90IHVzaW5nIHRoZSAnbW91c2V0cmFwJyBjbGFzcyBmdW5jdGlvbmFsaXR5LCB3aGljaCBhbGxvd3NcbiAgICAvLyB5b3UgdG8gd2hpdGVsaXN0IGVsZW1lbnRzLCBzbyBpZiB3ZSBjb21lIGFjcm9zcyBlbGVtZW50cyB3aXRoIHRoYXQgY2xhc3NcbiAgICAvLyB0aGVuIHdlIGNhbiBhc3N1bWUgdGhhdCB0aGV5IGFyZSBwcm92aWRlZCBieSB0aGUgc2l0ZSBpdHNlbGYsIG5vdCBieVxuICAgIC8vIHVzLCBzbyB3ZSBkb24ndCBhY3RpdmF0ZSBTaG9ydGtleXMgaW4gdGhhdCBjYXNlLCB0byBwcmV2ZW50IGNvbmZsaWN0cy5cbiAgICAvLyBUaGlzIGZpeGVzIHRoZSBjaGF0IGJveCBpbiBUd2l0Y2gudHYgZm9yIGV4YW1wbGUuXG4gICAgcmV0dXJuIHRydWVcbiAgfSBlbHNlIGlmICgha2V5U2V0dGluZy5hY3RpdmVJbklucHV0cykge1xuICAgIC8vIElmIHRoZSB1c2VyIGhhcyBub3QgY2hlY2tlZCBcIkFsc28gYWxsb3cgaW4gZm9ybSBpbnB1dHNcIiBmb3IgdGhpcyBzaG9ydGN1dCxcbiAgICAvLyB0aGVuIHdlIGN1dCBvdXQgb2YgdGhlIHVzZXIgaXMgaW4gYSBmb3JtIGlucHV0LlxuICAgIHJldHVybiBlbGVtZW50LnRhZ05hbWUgPT09ICdJTlBVVCcgfHxcbiAgICAgIGVsZW1lbnQudGFnTmFtZSA9PT0gJ1NFTEVDVCcgfHxcbiAgICAgIGVsZW1lbnQudGFnTmFtZSA9PT0gJ1RFWFRBUkVBJyB8fFxuICAgICAgZWxlbWVudC5pc0NvbnRlbnRFZGl0YWJsZVxuICB9IGVsc2Uge1xuICAgIC8vIFRoZSB1c2VyIEhBUyBjaGVja2VkIFwiQWxzbyBhbGxvdyBpbiBmb3JtIGlucHV0c1wiIGZvciB0aGlzIHNob3J0Y3V0IHNvIHdlXG4gICAgLy8gaGF2ZSBubyByZWFzb24gdG8gc3RvcCBpdCBmcm9tIHRyaWdnZXJpbmcuXG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxuLyoqXG4gKiBGZXRjaGVzIHRoZSBTaG9ydGtleXMgY29uZmlndXJhdGlvbiBvYmplY3QgYW5kIHdpcmVzIHVwIGVhY2ggY29uZmlndXJlZCBzaG9ydGN1dC5cbiAqL1xuY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe2FjdGlvbjogJ2dldEtleXMnLCB1cmw6IGRvY3VtZW50LlVSTH0sIGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICBpZiAocmVzcG9uc2UpIHtcbiAgICBTaG9ydGtleXMua2V5cyA9IHJlc3BvbnNlXG4gICAgaWYgKFNob3J0a2V5cy5rZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgIFNob3J0a2V5cy5rZXlzLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICBTaG9ydGtleXMuYWN0aXZhdGVLZXkoa2V5KVxuICAgICAgfSlcbiAgICB9XG4gIH1cbn0pXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9hcHAvc2NyaXB0cy9jb250ZW50c2NyaXB0LmpzIl0sInNvdXJjZVJvb3QiOiIifQ==